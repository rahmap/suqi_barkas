<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - Admin</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesdesign" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard/images/favicon.ico')); ?>">

    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('dashboard/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('dashboard/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('dashboard/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@9"></script>

    <?php echo $__env->yieldContent('outCSS'); ?>

</head>

<body data-topbar="dark" >

<!-- Begin page -->
<div id="layout-wrapper">

<?php echo $__env->make('layouts.admin.partials.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ============================================================== -->
    <!-- Start right Content here -->
    <!-- ============================================================== -->
    <div class="main-content">

        <?php echo $__env->yieldContent('contents'); ?>

        <?php echo $__env->make('layouts.admin.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <!-- end main content-->

</div>
<!-- END layout-wrapper -->

<?php echo $__env->make('layouts.admin.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- JAVASCRIPT -->
<script src="<?php echo e(asset('dashboard/libs/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/libs/metismenu/metisMenu.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/libs/simplebar/simplebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('dashboard/libs/node-waves/waves.min.js')); ?>"></script>

<script src="<?php echo e(asset('dashboard/js/app.js')); ?>"></script>

<?php echo $__env->yieldContent('outJS'); ?>

</body>
</html>
<?php /**PATH C:\laragon\www\suqi_barkas\resources\views/layouts/admin/v_main_admin.blade.php ENDPATH**/ ?>