<!-- ========== Left Sidebar Start ========== -->
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <li>
                    <a href="<?php echo e(route('admin_index')); ?>" class="waves-effect">
                        <i class="mdi mdi-view-dashboard"></i>
                        <span>Dashboard</span>
                    </a>
                </li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-email-multiple-outline"></i>
                        <span>Pelanggan</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('user.index')); ?>">List Pelanggan</a></li>
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-google-pages"></i>
                        <span>Produk</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('admin.produk.list')); ?>">List Produk</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-google-pages"></i>
                        <span>Kategori</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('kategori.create')); ?>">Tambah Kategori</a></li>
                        <li><a href="<?php echo e(route('kategori.index')); ?>">List Kategori</a></li>
                    </ul>
                </li>

                <li class="menu-title">Tools</li>
                <?php if(auth()->guard('admin')->user()->role == 'superadmin'): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="mdi mdi-share-variant"></i>
                        <span>Data Admin</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="true">
                        <li><a href="<?php echo e(route('admin.create')); ?>">Tambah Admin</a></li>
                        <li><a href="<?php echo e(route('admin.index')); ?>">List Admin</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(route('update_profile')); ?>" class=" waves-effect">
                        <i class="mdi mdi-calendar-month"></i>
                        <span>Profile</span>
                    </a>
                </li>

            </ul>

        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->
<?php /**PATH C:\laragon\www\suqi_barkas\resources\views/layouts/admin/partials/sidebar.blade.php ENDPATH**/ ?>