<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('outCSS'); ?>
<!-- SPECIFIC CSS -->
<link href="<?= asset('home/css/listing.css') ?>" rel="stylesheet">

<style>
    /* already defined in bootstrap4 */
    .text-xs-center {
        text-align: center;
    }

    .g-recaptcha {
        display: inline-block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <main>
        <div class="top_banner">
            <div class="opacity-mask d-flex align-items-center" data-opacity-mask="rgba(0, 0, 0, 0.3)">
                <div class="container">
                    <div class="breadcrumbs">

                    </div>
                    <h1><?php echo e($title); ?> - <?php echo e(getenv('APP_NAME')); ?></h1>
                </div>
            </div>
            <img src="home/img/bg_cat_shoes.jpg" class="img-fluid" alt="">
        </div>
        <!-- /top_banner -->
        <div id="stick_here"></div>
        <div class="toolbox elemento_stick">
            <div class="container">
                <ul class="clearfix">
                    <li>

                    </li>
                    <li>

                    </li>
                    <li>
                        <a href="#0" class="open_filters">
                            <i class="ti-filter"></i><span>Filters</span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /toolbox -->
        <?php if($relates->isNotEmpty()): ?>
            <div class="container margin_60_15 mb-4">
                <div class="main_title">
                    <h2>Featured</h2>
                    <span>Paketan</span>
                    <p>Menampilkan produk dengan Kategori <strong>Paketan</strong>.</p>
                </div>
                <div class="owl-carousel owl-theme products_carousel">
                    <?php $__currentLoopData = $relates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="grid_item">
                                <?php if($pro['diskon'] > 0): ?><span class="ribbon off">-<?php echo e($pro['diskon']); ?>%</span> <?php endif; ?>
                                <figure>
                                    <a href="<?php echo e(url('produk/'.$pro['slug'])); ?>">
                                        <img class="img-fluid lazy" style="height: 163px" src="<?php echo e(asset('storage/product/'.$pro['gambar'])); ?>"
                                             data-src="<?php echo e(asset('storage/product/'.$pro['gambar'])); ?>" alt="Gambar <?php echo e($pro['nama']); ?>">
                                    </a>
                                </figure>
                                <small><a href="<?php echo e(url('filter?kategori='.$pro['kategoris']['slug'])); ?>"><?php echo e($pro['kategoris']['nama']); ?></a></small>
                                <br>
                                <a href="<?php echo e(url('produk/'.$pro['slug'])); ?>">
                                    <h3><?php echo e($pro['nama']); ?></h3>
                                </a>
                                <div class="price_box">
                                    <span class="new_price">Rp <?php echo e(formatRupiah($pro['harga'] = $pro['harga'] - ($pro['harga'] * $pro['diskon'] / 100))); ?></span>
                                </div>
                                <ul>

                                </ul>
                            </div>
                            <!-- /grid_item -->
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- /item -->
                </div>
                <div class="row justify-content-center">
                    <a href="<?php echo e(url('filter?kategori=paketan')); ?>"><strong>Lihat Selengkapnya</strong></a>
                </div>
                <!-- /products_carousel -->
                <!-- /col -->
            </div>
            <!-- /container -->
        <hr>
        <?php endif; ?>
        <div class="container">

            <div class="row">
                <?php echo $__env->make('layouts.v_sidebar_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- /col -->
                <div class="col-lg-9">
                    <div class="row small-gutters">
                        <?php if(!$produks->isEmpty()): ?>
                            <?php $__currentLoopData = $produks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-md-4">
                                    <div class="grid_item">
                                        <?php if($pro['diskon'] > 0): ?><span class="ribbon off">-<?php echo e($pro['diskon']); ?>%</span> <?php endif; ?>
                                        <figure>
                                            <a href="<?php echo e(url('produk/'.$pro['slug'])); ?>">
                                                <img class="img-fluid lazy" style="height: 163px" src="<?php echo e(asset('storage/product/'.$pro['gambar'])); ?>"
                                                     data-src="<?php echo e(asset('storage/product/'.$pro['gambar'])); ?>" alt="Gambar <?php echo e($pro['nama']); ?>">
                                            </a>
                                        </figure>
                                        <small><a href="<?php echo e(url('/filter?kategori=').$pro['kategoris']['slug']); ?>"><?php echo e($pro['kategoris']['nama']); ?></a></small>
                                            <br>
                                        <small>
                                            <span><?php echo e($pro['users']['provinsi']); ?></span>
                                            -
                                            <span><?php echo e($pro['users']['kabupaten']); ?></span>
                                        </small>
                                        <br>
                                        <a href="<?php echo e(url('produk/'.$pro['slug'])); ?>">
                                            <h3><?php echo e($pro['nama']); ?></h3>
                                        </a>
                                        <div class="price_box">
                                            <span class="new_price">Rp <?php echo e(formatRupiah($pro['harga'] = $pro['harga'] - ($pro['harga'] * $pro['diskon'] / 100))); ?></span>
                                        </div>
                                        <ul>

                                        </ul>
                                    </div>
                                    <!-- /grid_item -->
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <!-- /col -->
                        <?php else: ?>
                            <div class="col-12 col-md-12">
                                <div class="text-center">
                                    <h3>Tidak ada data Produk</h3>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>
                   <?php if(!empty($produks)): ?> <?php echo $produks->links(); ?> <?php endif; ?>
                </div>
                <!-- /col -->
            </div>
            <!-- /row -->

        </div>
        <!-- /container -->
    </main>
    <!-- /main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('outJS'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.2/js/umd/util.js"></script>
<!-- SPECIFIC SCRIPTS -->
<script src="<?php echo e(asset('home/js/sticky_sidebar.min.js')); ?>"></script>
<script src="<?php echo e(asset('home/js/specific_listing.js')); ?>"></script>
<script>
    $(document).ready(function (){
        $('input[name="client_type"]').on("click", function() {
            let inputValue = $(this).attr("value");
            let targetBox = $("." + inputValue);
            $(".box").not(targetBox).hide();
            $(targetBox).show();
        });
        let pagi =  $('.pagination')
        let nav = pagi.parents('nav')
        nav.addClass('pagination__wrapper')

        pagi.find('li.active').removeAttr('class').children(this).addClass('active')

    })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/v_main_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suqi_barkas\resources\views/home/v_home_index.blade.php ENDPATH**/ ?>