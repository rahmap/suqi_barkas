<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('outCSS'); ?>
<!-- SPECIFIC CSS -->
<link href="<?= asset('home/css/account.css') ?>" rel="stylesheet">

<style>
    /* already defined in bootstrap4 */
    .text-xs-center {
        text-align: center;
    }

    .g-recaptcha {
        display: inline-block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
<main class="bg_gray">

    <div class="container margin_30">
        <div class="page_header">
            <div class="breadcrumbs">
                <ul>
                    <li><a href="<?= route('home') ?>">Home</a></li>
                    <li><a href="<?= route('auth') ?>">Auth</a></li>
                </ul>
                <h1>Masuk</h1>
            </div>
            <!--			<h1>Buat Akan Baru</h1>-->
        </div>
        <!-- /page_header -->
        <div class="row justify-content-center">
            <div class="col-xl-8 col-lg-8 col-md-10">
                <div class="box_account">
                    <h3 class="client">Sudah Punya Akun</h3>
                    <div class="form_container">
                        <?= (session()->has('messageLogin'))? session()->messageLogin : '' ?>
                        <form action="<?= route('auth_login_admin') ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <input type="email" class="form-control <?php $__errorArgs = ['email_login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       value="<?= old('email_login'); ?>" name="email_login" id="email_login" placeholder="Email*" required>
                                <?php $__errorArgs = ['email_login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control <?php $__errorArgs = ['password_login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       name="password_login" id="password_login_in"
                                       required minlength="6"
                                       placeholder="Password*">
                                <?php $__errorArgs = ['password_login'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback">
                                    <?php echo e($message); ?>

                                </div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="text-center" style="margin-top: 10px;"><input type="submit" value="Masuk" class="btn_1 full-width"></div>
                        </form>
                    </div>
                    <!-- /form_container -->
                </div>
                <!-- /box_account -->

                <!-- /row -->
            </div>
        </div>
        <!-- /row -->
    </div>
    <!-- /container -->
</main>
<!--/main-->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('outJS'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.2/js/umd/util.js"></script>

<script>
    $(document).ready(function (){
        $('input[name="client_type"]').on("click", function() {
            let inputValue = $(this).attr("value");
            let targetBox = $("." + inputValue);
            $(".box").not(targetBox).hide();
            $(targetBox).show();
        });

        let checkEmailForgot = "<?= session()->has('messageForgetEmail') ?>";
        if(checkEmailForgot){
            $('#forgot').click()
        }

        $('#btnKembaliForgot').click(function (){
            $('#forgot_pw').hide()
        })
    })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/v_main_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suqi_barkas\resources\views/auth/v_auth_admin.blade.php ENDPATH**/ ?>