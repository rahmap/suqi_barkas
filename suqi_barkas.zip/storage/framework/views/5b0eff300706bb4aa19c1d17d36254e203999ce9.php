<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('outCSS'); ?>
<!-- SPECIFIC CSS -->
<link href="<?php echo e(asset('home/css/product_page.css')); ?>" rel="stylesheet">
<style>
    /* already defined in bootstrap4 */
    .text-xs-center {
        text-align: center;
    }

    .g-recaptcha {
        display: inline-block;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <main>
        <div class="container margin_30">
            <div class="row">
                <div class="col-md-6">
                    <div class="all">
                        <div class="slider">
                            <div class="owl-carousel owl-theme main">
                                <div style="background-image: url(<?php echo e(asset('storage/product/'.$produk['gambar'])); ?>);" class="item-box"></div>
                                <div style="background-image: url(<?php echo e(asset('storage/product/'.$produk['gambar_tambahan'])); ?>);" class="item-box"></div>
                            </div>
                            <div class="left nonl"><i class="ti-angle-left"></i></div>
                            <div class="right"><i class="ti-angle-right"></i></div>
                        </div>
                        <div class="slider-two">
                            <div class="owl-carousel owl-theme thumbs">
                                <div style="background-image: url(<?php echo e(asset('storage/product/'.$produk['gambar'])); ?>);" class="item active"></div>
                                <div style="background-image: url(<?php echo e(asset('storage/product/'.$produk['gambar_tambahan'])); ?>);" class="item"></div>
                            </div>
                            <div class="left-t nonl-t"></div>
                            <div class="right-t"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <!-- /page_header -->
                    <div class="prod_info">
                        <h1><?php echo e($produk['nama']); ?></h1>
                        <p><small>Kategori : <a href="<?php echo e(url('/filter?kategori=').$produk['kategoris']['slug']); ?>"><?php echo e($produk['kategoris']['nama']); ?></a></small></p>
                        <p>
                            <small>Nama Penjual :
                                <a href="<?php echo e(route('home.penjual',['user_name_slug' => $produk['users']['id'].'-'.str_replace(' ','-',strtolower($produk['users']['nama']))])); ?>">
                                    <?php echo e($produk['users']['nama']); ?>

                                </a>
                            </small>
                        </p>
                        <p><small>Lokasi : <?php echo e($produk['users']['provinsi']); ?> - <?php echo e($produk['users']['kabupaten']); ?></small></p>
                        <div class="row">
                            <div class="col-lg-5 col-md-6">
                                <?php if($produk['diskon'] > 0): ?>
                                <div class="price_main"><span class="new_price">Rp <?php echo e(formatRupiah($produk['harga'] - ($produk['harga'] * $produk['diskon'] / 100))); ?></span><span class="percentage">
                                        -<?php echo e($produk['diskon']); ?>%</span> <span class="old_price">Rp <?php echo e(formatRupiah($produk['harga'])); ?></span></div>
                                <?php else: ?>
                                    <div class="price_main"><span class="new_price">Rp <?php echo e(formatRupiah($produk['harga'])); ?></span></div>
                                <?php endif; ?>
                            </div>
                            <div class="col-lg-4 col-md-6">
                                <a target="_blank"
                                   href="https://wa.me/<?php echo e($produk['users']['phone']); ?>?text=Hallo *<?php echo e($produk['users']['nama']); ?>*, saya tertarik pada produk *<?php echo e($produk['nama']); ?>*">
                                    <div class="btn_add_to_cart"><button type="submit" class="btn_1">Chat Sekarang</button></div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- /prod_info -->
                </div>
            </div>
            <!-- /row -->
        </div>
        <!-- /container -->

        <div class="tabs_product">
            <div class="container">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a id="tab-A" href="#pane-A" class="nav-link active" data-toggle="tab" role="tab">Deskripsi</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /tabs_product -->
        <div class="tab_content_wrapper">
            <div class="container">
                <div class="tab-content" role="tablist">
                    <div id="pane-A" class="card tab-pane fade active show" role="tabpanel" aria-labelledby="tab-A">
                        <div class="card-header" role="tab" id="heading-A">
                            <h5 class="mb-0">
                                <a class="collapsed" data-toggle="collapse" href="#collapse-A" aria-expanded="false" aria-controls="collapse-A">
                                    Deskripsi
                                </a>
                            </h5>
                        </div>
                        <div id="collapse-A" class="collapse" role="tabpanel" aria-labelledby="heading-A">
                            <div class="card-body">
                                <div class="row justify-content-center">
                                    <div class="col-lg-8">
                                        <h3>Keterangan <?php if($produk['kategoris']['slug'] == 'paketan' OR $produk['kategoris']['slug'] == 'paket'): ?> Paket <?php else: ?> Produk <?php endif; ?> <?php echo e($produk['nama']); ?></h3>
                                        <?php echo $produk['keterangan']; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /TAB A -->
                </div>
                <!-- /tab-content -->
            </div>
            <!-- /container -->
        </div>
        <!-- /tab_content_wrapper -->

    <?php if(!empty($relates)): ?>
        <div class="container margin_60_35">
            <div class="main_title">
                <h2>Related</h2>
                <span>Produk</span>
                <p>Produk yang mungkin anda suka.</p>
            </div>
            <div class="owl-carousel owl-theme products_carousel">
                <?php $__currentLoopData = $relates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="grid_item">
                        <?php if($pro['diskon'] > 0): ?><span class="ribbon off">-<?php echo e($pro['diskon']); ?>%</span> <?php endif; ?>
                        <figure>
                            <a href="<?php echo e(url('produk/'.$pro['slug'])); ?>">
                                <img class="img-fluid lazy" style="height: 163px" src="<?php echo e(asset('storage/product/'.$pro['gambar'])); ?>"
                                     data-src="<?php echo e(asset('storage/product/'.$pro['gambar'])); ?>" alt="Gambar <?php echo e($pro['nama']); ?>">
                            </a>
                        </figure>
                        <small><a href="<?php echo e(url('filter?kategori='.$pro['kategoris']['slug'])); ?>"><?php echo e($pro['kategoris']['nama']); ?></a></small>
                        <br>
                        <a href="<?php echo e(url('produk/'.$pro['slug'])); ?>">
                            <h3><?php echo e($pro['nama']); ?></h3>
                        </a>
                        <div class="price_box">
                            <span class="new_price">Rp <?php echo e(formatRupiah($pro['harga'] = $pro['harga'] - ($pro['harga'] * $pro['diskon'] / 100))); ?></span>
                        </div>
                        <ul>

                        </ul>
                    </div>
                    <!-- /grid_item -->
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <!-- /item -->

            </div>
            <!-- /products_carousel -->
                <!-- /col -->
        </div>
        <!-- /container -->
    <?php endif; ?>

    </main>
    <!-- /main -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('outJS'); ?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.2/js/umd/util.js"></script>
<!-- SPECIFIC SCRIPTS -->
<script  src="<?php echo e(asset('home/js/carousel_with_thumbs.js')); ?>"></script>
<script>
    $(document).ready(function (){
        $('input[name="client_type"]').on("click", function() {
            let inputValue = $(this).attr("value");
            let targetBox = $("." + inputValue);
            $(".box").not(targetBox).hide();
            $(targetBox).show();
        });


    })
</script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/v_main_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suqi_barkas\resources\views/home/v_home_single_page.blade.php ENDPATH**/ ?>