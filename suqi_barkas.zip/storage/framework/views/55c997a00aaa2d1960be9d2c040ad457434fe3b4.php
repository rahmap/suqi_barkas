<?php if(!isset($pageNama)): ?>
<aside class="col-lg-3" id="sidebar_fixed">
    <div class="filter_col">
        <div class="inner_bt"><a href="#" class="open_filters"><i class="ti-close"></i></a></div>
        <form action="<?php echo e(route('filter')); ?>" method="get">
        <div class="filter_type version_2">
            <h4><a href="#filter_1" data-toggle="collapse" class="opened">Kategori</a></h4>
            <div class="collapse show" id="filter_1">
                <ul>
                    <?php $__currentLoopData = $kategoris; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <label class="container_check"><?php echo e($kat['nama']); ?> <small><?php echo e(count($kat['produks'])); ?></small>
                            <input type="radio" value="<?php echo e($kat['slug']); ?>" <?php if(isset($_GET['kategori']) AND $_GET['kategori'] == $kat['slug']): ?> checked <?php endif; ?> name="kategori">
                            <span class="checkmark"></span>
                        </label>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <!-- /filter_type -->
        </div>

        <!-- /filter_type -->
        <div class="buttons text-center">
            <button class="btn_1" type="submit">Filter</button> <button type="reset" class="btn_1 gray">Reset</button>
        </div>
        </form>
    </div>
</aside>
<?php endif; ?>
<?php /**PATH C:\laragon\www\suqi_barkas\resources\views/layouts/v_sidebar_home.blade.php ENDPATH**/ ?>