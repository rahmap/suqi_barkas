<?php $__env->startSection('title', $title); ?>

<?php $__env->startSection('outCSS'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('contents'); ?>
    <?php if(\session()->has('message')): ?>
        <?php echo \session()->get('message'); ?>

    <?php endif; ?>
    <div class="page-content">
        <div class="container-fluid">


        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-flex align-items-center justify-content-between">
                    <h4 class="mb-0 font-size-18"><?php echo e($title); ?></h4>



                </div>
            </div>
        </div>


















































































        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('outJS'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer.v_main_customer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\suqi_barkas\resources\views/customer/v_customer_index.blade.php ENDPATH**/ ?>